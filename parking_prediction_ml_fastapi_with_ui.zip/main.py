
from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
import joblib
import numpy as np

app = FastAPI()
templates = Jinja2Templates(directory="templates")
model = joblib.load("model.pkl")

@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.post("/predict", response_class=HTMLResponse)
def predict(request: Request, hour: int = Form(...), day: int = Form(...)):
    pred = model.predict(np.array([[hour, day]]))[0]
    return templates.TemplateResponse(
        "index.html",
        {
            "request": request,
            "prediction": round(float(pred), 2),
            "hour": hour,
            "day": day
        }
    )
